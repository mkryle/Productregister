


	PHP LABB 2 - Marucs Kryle


Skapa en databas i mysql med namn:  minDatabas

Se "wireframe.png" f�r Wireframe
 

(	
	 http://localhost/phpmyadmin/ 

	"Ny"
	
	Databasnamn: minDatabas

	uft8_swedish_ci

	"Skapa"
						)
	



